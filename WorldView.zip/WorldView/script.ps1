$images = Get-ChildItem -Path "Z:\LB_BAS\SpinningGlobe\bmp" -Filter *.bmp | Sort-Object { [int]($_.BaseName) }
magick convert -delay 0 -loop 0 $images.FullName outputHOPE.gif