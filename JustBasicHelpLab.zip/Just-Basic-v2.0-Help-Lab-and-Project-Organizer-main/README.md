'Name = Just Basic v2.0 Help Lab and Project Organizer v1.0

'Author(s) - xxgeek, cundo, Carl Gundel

'Date - Nov 2021

'_Visit the Just Basic forums @ justbasiccom.proboards.com/ for more information.

'_Purpose - To help new users learn to code in Just Basic v2.0_


'_This program is a collection of other programs written by other users,_
'_ and by Carl Gundel(creator of the Just Basic language)_

'_Credit goes to cundo for the jbsearch (an engine to search the jb help files) _
'_Credit also goes to cundo for the fastcode code generator that creates _
'_the shell "Window" Code _
'_Credit goes to Rod for SpriteCreator and many answers to my questions _
' and must add, a shared enthusiasm and passion for coding and helping others
'_Credit goes to Carl Gundel for his Dictionary code and his quick responses _
'_to questions regarding Just Basic's nuances and buried details _
'_Credit goes to tsh73 for his inspiration, advice, help, and most of all his _
'_code "proof of concept" which was the initial code to show that a TKN file _
'_can be created programatically that got this project moving forward. _
'_Credit goes to the following members who helped with all questions posed while _
'_learning to code in Just Basic v2.0 _
'_B+ for his many code samples and his desire to help others learn to code,
' not to mention his exceptional skills regarding math +(geomentry) and graphics coding
' enzo for his enthusiasm, his superb ideas, his willingness to help others, and the
' "OutoftheBox" kind of thinking he exibits
'_code (yes "code" is a member) he writes some good code, and code helps me out
' as well, so he gets a mention here too.
' Hope I didn't forget anyone, if I did, it's cause my memory can fail me.
' Sorry, let me know if I forgot YOU.

'All are members of the Just Basic forums, and waiting to help YOU when you
' decide to code in Just Basic. Just ask for help at the Just Basic forums and
'they (and I) will help with whatever you need regarding Just Basic
